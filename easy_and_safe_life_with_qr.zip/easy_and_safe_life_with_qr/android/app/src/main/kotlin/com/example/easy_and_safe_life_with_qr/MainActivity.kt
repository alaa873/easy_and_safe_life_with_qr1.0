package com.example.easy_and_safe_life_with_qr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
